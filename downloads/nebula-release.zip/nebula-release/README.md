<div align="center">

<img src="icon-512.png" alt="Nebula AI Pro" width="120" />

# ⚡ Nebula AI Pro

**Mobile-first AI PWA · 17 free providers · 8 visual themes · No backend · Zero cost**

[![Deploy to Netlify](https://img.shields.io/badge/Deploy-Netlify-00C7B7?style=for-the-badge&logo=netlify&logoColor=white)](https://app.netlify.com/drop)
[![PWA Ready](https://img.shields.io/badge/PWA-Ready-5A0FC8?style=for-the-badge&logo=pwa&logoColor=white)](#install-as-app)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue?style=for-the-badge)](LICENSE)
[![Version](https://img.shields.io/badge/Version-2.3-success?style=for-the-badge)](#changelog)

[![Stars](https://img.shields.io/github/stars/curiousstitches/Nebula-V3?style=social)](https://github.com/curiousstitches/Nebula-V3/stargazers)
[![Forks](https://img.shields.io/github/forks/curiousstitches/Nebula-V3?style=social)](https://github.com/curiousstitches/Nebula-V3/network/members)
[![Last Commit](https://img.shields.io/github/last-commit/curiousstitches/Nebula-V3)](https://github.com/curiousstitches/Nebula-V3/commits/main)

[**🚀 Live Demo**](https://curiousstitches.github.io/Nebula-V3) · [**📖 Docs**](docs/) · [**🐛 Report Bug**](https://github.com/curiousstitches/Nebula-V3/issues/new?template=bug_report.md) · [**💡 Request Feature**](https://github.com/curiousstitches/Nebula-V3/issues/new?template=feature_request.md)

</div>

---

## 📸 Screenshots

<div align="center">

<table>
<tr>
<td align="center"><b>Forest Realm (Default)</b><br><img src="screenshots/chat-forest.png" width="180"/></td>
<td align="center"><b>Fire Realm</b><br><img src="screenshots/chat-fire.png" width="180"/></td>
<td align="center"><b>Cosmic</b><br><img src="screenshots/chat-cosmic.png" width="180"/></td>
<td align="center"><b>Neon City</b><br><img src="screenshots/chat-neon.png" width="180"/></td>
</tr>
<tr>
<td align="center"><b>Theme Picker</b><br><img src="screenshots/themes.png" width="180"/></td>
<td align="center"><b>Router Tab</b><br><img src="screenshots/router-forest.png" width="180"/></td>
<td align="center"><b>Forest Theme Detail</b><br><img src="screenshots/themes-forest.png" width="180"/></td>
<td align="center"><b>More Themes</b><br><em>Water · Shadow · Sakura · Volcanic · Minimal</em></td>
</tr>
</table>

</div>

---

## ✨ Features

<table>
<tr>
<td width="50%">

### 🤖 AI Chat
- 17 free AI providers — 5 need **zero** setup
- Real SSE streaming (text appears live)
- Stop generation mid-response
- Conversation history with memory toggle
- Auto-fallback if a provider fails
- Custom system prompts

</td>
<td width="50%">

### 🎨 8 Visual Themes
- **Forest Realm** — Hyrule-inspired, gold knotwork, fireflies *(default)*
- **Fire Realm** — volcanic red with rising embers
- **Water Realm** — aquatic blue with rising bubbles
- **Shadow Realm** — eerie purple wisps
- **Cosmic** — nebula backdrop, twinkling stars
- **Neon City** — cyberpunk cyan/magenta grid
- **Sakura** — falling cherry blossom petals
- **Volcanic** — lava glow ember storm

</td>
</tr>
<tr>
<td width="50%">

### 🔊 Original Audio
- Web Audio API synthesized SFX (zero files)
- Themed ambient music (8 original compositions)
- Click, chime, send, receive sound effects
- Master mute · volume slider · per-theme mood

</td>
<td width="50%">

### 🛠️ 15 AI Tools
Translate · Keywords · Sentiment · Idea Gen · Email Writer · Story Gen · Tweet Gen · SEO Writer · Regex Gen · SQL Gen · Unit Tests · Write Docs · Summarize · Rewrite · Explain

</td>
</tr>
<tr>
<td width="50%">

### 🔄 9Router Integration
- Smart multi-provider routing
- Auto-fallback on quota limits
- 20-40% token savings (RTK)
- Dedicated setup tab

</td>
<td width="50%">

### 🖥️ Puter SDK (No Key!)
- Free GPT-4o chat
- Free Claude Sonnet 4 chat
- Free DALL-E image generation
- No signup, no API key

</td>
</tr>
</table>

### ⚙️ Advanced Controls
**Visual:** 3D card tilt · particle density slider · background animation · performance mode · motion-off  
**Audio:** SFX toggle · ambient music toggle · volume slider  
**Conversation:** memory toggle · streaming toggle · auto-fallback · export chat JSON

---

## 🚀 Quick Start

### Deploy in 30 seconds (no account needed)
1. Download this repo as a ZIP
2. Drag the folder to **[app.netlify.com/drop](https://app.netlify.com/drop)**
3. Get an instant live HTTPS URL ✅

### Run locally
```bash
git clone https://github.com/curiousstitches/Nebula-V3.git
cd Nebula-V3
python3 -m http.server 8000
# visit http://localhost:8000
```

No `npm install`. No build step. One HTML file.

---

## 🤖 AI Providers

### ✅ No API Key Required
| Provider | Model |
|----------|-------|
| **Pollinations AI** | OpenAI-compatible |
| **Puter • GPT-4o** | GPT-4o (via Puter SDK) |
| **Puter • Claude Sonnet 4** | Claude Sonnet 4 (via Puter SDK) |
| **OpenRouter • Llama 3.1** | Llama 3.1 8B Instruct (free tier) |
| **OpenRouter • Gemma 2** | Gemma 2 9B IT (free tier) |

### 🔑 Free Tier with API Key
| Provider | Model | Get Key |
|----------|-------|---------|
| Google Gemini | Gemini 2.0 Flash | [aistudio.google.com](https://aistudio.google.com/apikey) |
| Groq | Llama 3.3 70B | [console.groq.com](https://console.groq.com/keys) |
| Mistral AI | Mistral Small | [console.mistral.ai](https://console.mistral.ai/api-keys) |
| Cohere | Command R | [dashboard.cohere.com](https://dashboard.cohere.com/api-keys) |
| Together AI | Llama 3 8B | [api.together.xyz](https://api.together.xyz/settings/api-keys) |
| DeepSeek | DeepSeek Chat | [platform.deepseek.com](https://platform.deepseek.com/api_keys) |
| Cerebras | Llama 3.1 8B | [cloud.cerebras.ai](https://cloud.cerebras.ai/platform) |
| GitHub Models | GPT-4o Mini | [github.com/settings/tokens](https://github.com/settings/tokens) |
| SambaNova | Llama 3.1 8B | [cloud.sambanova.ai](https://cloud.sambanova.ai/apis) |
| HuggingFace | Mistral 7B v0.3 | [huggingface.co](https://huggingface.co/settings/tokens) |
| AI21 | Jamba Mini | [studio.ai21.com](https://studio.ai21.com/account/api-keys) |
| **9Router** | Auto (40+ providers) | [9router.com](https://9router.com) |

---

## 📱 Install as App

| Platform | Steps |
|----------|-------|
| **Android** | Chrome → ⋮ → Install app |
| **iPhone** | Safari → Share → Add to Home Screen |
| **Desktop** | Chrome/Edge → ⊕ icon in address bar |

Launches in its own window. Works offline (UI only — AI needs internet).

---

## 📁 Project Structure

```
Nebula-V3/
├── index.html              # Complete app (~89KB, single file)
├── sw.js                   # Service worker (offline + PWA)
├── manifest.json           # PWA config
├── icon-192.png            # App icon
├── icon-512.png            # App icon (large)
├── screenshots/            # App screenshots
├── docs/                   # Extended documentation
│   ├── PROVIDERS.md        # Provider setup guides
│   ├── THEMES.md           # Theme customization
│   └── FAQ.md              # Common questions
├── .github/
│   ├── ISSUE_TEMPLATE/     # Bug & feature templates
│   ├── PULL_REQUEST_TEMPLATE.md
│   └── workflows/
│       └── deploy.yml      # Auto-deploy to GitHub Pages
├── README.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── CODE_OF_CONDUCT.md
├── SECURITY.md
└── LICENSE
```

---

## 🏗️ How It Works

Pure HTML5 + CSS3 + Vanilla JavaScript. No framework. No build step.

- **Streaming:** SSE parser handles OpenAI-compatible providers live
- **Audio:** Web Audio API generates all sounds procedurally — no audio files
- **Particles:** Canvas-based, 7 particle types, GPU-friendly
- **Themes:** CSS custom properties switched via `data-theme` attribute
- **State:** `localStorage` for settings, keys, conversation history
- **PWA:** Service worker with network-first HTML, cache-first assets

---

## 🔐 Privacy & Security

- **No backend** — runs entirely in your browser
- **No tracking** — zero analytics, no cookies, no telemetry
- **Local keys only** — API keys stored in `localStorage`, never sent anywhere except directly to that provider
- **XSS-safe** — all user input and AI output uses `textContent`, never `innerHTML`
- **Original audio** — no third-party copyrighted sounds or music bundled

---

## 🤝 Contributing

All contributions welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

**Easy entry points:**
- Add a new provider (~5 lines in the `PROVIDERS` object)
- Add a new tool (~3 lines in the `TOOLS` object)
- Add a new theme (~30 lines CSS + 1 JS entry)

```bash
# Fork → clone → branch → PR
git checkout -b feature/my-feature
git commit -m 'feat: describe your change'
git push origin feature/my-feature
```

---

## 📜 Changelog

See [CHANGELOG.md](CHANGELOG.md) for full version history.

**v2.3** — Themes, audio, particles  
**v2.2** — Real API calls, streaming, security fixes  
**v2.1** — Mobile viewport fixes, 20+ providers  
**v2.0** — Desktop interface redesign  

---

## 📄 License

MIT — free to use, fork, modify, and distribute. See [LICENSE](LICENSE).

---

## 🙏 Credits

[Pollinations AI](https://pollinations.ai) · [Puter](https://puter.com) · [OpenRouter](https://openrouter.ai) · [9Router](https://9router.com) · [Groq](https://groq.com) · [Google Gemini](https://deepmind.google/technologies/gemini/) · [Mistral](https://mistral.ai) · [Meta Llama](https://llama.meta.com)

---

<div align="center">

**If this project helps you, please [⭐ star the repo](https://github.com/curiousstitches/Nebula-V3) — it helps others find it.**

</div>
