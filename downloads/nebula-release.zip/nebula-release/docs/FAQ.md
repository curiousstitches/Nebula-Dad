# Frequently Asked Questions

## General

**Does this cost anything?**  
No. Five providers work with zero setup. The other twelve have free tiers — you just need to sign up at the provider's site.

**Do I need to install anything?**  
No. It's a single HTML file. Open it in any browser or deploy to any static host.

**Does it work offline?**  
The UI loads offline once cached by the service worker. AI responses require internet.

---

## Providers

**Which providers need no API key?**  
Pollinations AI, Puter • GPT-4o, Puter • Claude Sonnet 4, OpenRouter • Llama 3.1 Free, OpenRouter • Gemma 2 Free.

**Where are my API keys stored?**  
In your browser's `localStorage`. They never leave your device except as Authorization headers sent directly to the provider's API.

**A provider says "Needs key" but I pasted my key — why?**  
Make sure you tapped the provider card *after* pasting the key. The key input saves automatically on each keystroke, but the card must be tapped to become active.

**Why is Puter showing an error?**  
Puter.js requires an internet connection to load. If you're on a slow connection, wait a few seconds and try again.

---

## Themes & Audio

**How do I change the theme?**  
Tap the 🎨 Themes tab → tap any theme tile. Changes instantly.

**Why can't I hear sounds?**  
- Tap the 🔊 icon in the header to unmute
- Make sure your device isn't on silent/vibrate
- Browsers require a user gesture before playing audio — tap anything first

**Why can't I hear music?**  
Music is off by default. Go to Themes tab → Audio section → enable "Ambient Music". Music starts on your next tap (browser autoplay policy requires a user gesture).

**Can I add custom themes?**  
Yes — see [CONTRIBUTING.md](../CONTRIBUTING.md#adding-a-new-theme). It's about 30 lines.

---

## 9Router

**What is 9Router?**  
A local AI gateway that routes across 40+ providers with smart fallback and token optimization. Optional — the app works without it.

**How do I set it up?**  
```bash
npm install -g 9router
9router
```
Then in the app, open the 🔄 9Router tab and tap Connect & Test.

---

## Deployment

**What's the easiest way to deploy?**  
Drag the project folder to [app.netlify.com/drop](https://app.netlify.com/drop). Takes 30 seconds.

**Can I use a custom domain?**  
Yes — Netlify and GitHub Pages both support custom domains for free.

**Why won't it install as a PWA?**  
PWA installation requires HTTPS. Use Netlify or GitHub Pages rather than a `file://` URL. On iOS, Safari is required (not Chrome).
