---
name: 💡 Feature Request
about: Suggest an improvement or new feature
title: '[FEATURE] '
labels: enhancement
---

## What problem does this solve?
<!-- Is your feature request related to a problem? Describe it. -->

## Describe the solution
<!-- What do you want to happen? -->

## Alternatives considered
<!-- Any alternative solutions you've thought about? -->

## Additional context
<!-- Screenshots, mockups, examples from other apps? -->

## Would you be willing to implement this?
- [ ] Yes, I'd like to submit a PR
- [ ] No, just requesting
