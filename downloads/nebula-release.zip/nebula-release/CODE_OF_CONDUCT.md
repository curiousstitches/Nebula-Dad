# Code of Conduct

## Our Pledge

We pledge to make participation in this project a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity, experience level, nationality, appearance, race, religion, or sexual identity.

## Our Standards

**Positive behavior:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints
- Accepting constructive criticism gracefully
- Focusing on what is best for the community

**Unacceptable behavior:**
- Harassment, trolling, or personal attacks
- Publishing others' private information
- Sexualized language or imagery
- Other conduct reasonably considered inappropriate

## Enforcement

Instances of unacceptable behavior may be reported by opening a GitHub issue or contacting the maintainer directly. All complaints will be reviewed and investigated.

---

*Adapted from the [Contributor Covenant v2.0](https://www.contributor-covenant.org/version/2/0/code_of_conduct.html)*
