## What does this PR do?
<!-- Brief description. Fixes #issue_number if applicable. -->

## Type of change
- [ ] 🐛 Bug fix
- [ ] ✨ New feature (provider / tool / theme / other)
- [ ] 📚 Documentation
- [ ] ♻️ Refactor / performance
- [ ] 🔒 Security fix

## Testing
- [ ] Tested locally (`python3 -m http.server 8000`)
- [ ] Tested on mobile viewport
- [ ] No console errors
- [ ] Chat sends/receives correctly
- [ ] Settings persist after reload

## Screenshots (if visual change)
| Before | After |
|--------|-------|
| | |
