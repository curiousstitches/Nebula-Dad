---
name: 🐛 Bug Report
about: Something isn't working
title: '[BUG] '
labels: bug
---

## What's broken
<!-- Clear description of the bug -->

## Steps to reproduce
1. Go to '...'
2. Tap/click '...'
3. See error

## Expected vs actual
**Expected:** ...  
**Actual:** ...

## Screenshots
<!-- If applicable -->

## Environment
- **Device:** (e.g. iPhone 14, Samsung S21, Desktop)
- **Browser:** (e.g. Chrome 120, Safari 17)
- **OS:** (e.g. iOS 17, Android 14, Windows 11)

## AI Provider (if chat-related)
- [ ] Pollinations AI
- [ ] Puter • GPT-4o
- [ ] Puter • Claude
- [ ] OpenRouter
- [ ] Gemini
- [ ] Groq
- [ ] Other: ___

## Console errors (F12 → Console)
```
paste any errors here
```
