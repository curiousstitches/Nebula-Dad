# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 2.x     | ✅ Yes    |
| 1.x     | ❌ No     |

## Reporting a Vulnerability

**Please do not report security vulnerabilities through public GitHub issues.**

Open a [GitHub Security Advisory](../../security/advisories/new) or contact the maintainer directly.

Include: vulnerability type, steps to reproduce, potential impact.

You'll receive a response within 48 hours.

## Security Design

- **No backend** — runs client-side only
- **No data collection** — nothing stored outside your own browser
- **Local key storage** — API keys in `localStorage`, never transmitted except directly to the provider API
- **XSS-safe** — `textContent` throughout, no `innerHTML` with variable data
- **No third-party scripts** except `js.puter.com/v2/` (Puter SDK, optional)

## Best Practices for Deployers

- Serve over HTTPS (required for PWA features)
- Do not hardcode API keys in the source
- Use free-tier keys rather than production keys
