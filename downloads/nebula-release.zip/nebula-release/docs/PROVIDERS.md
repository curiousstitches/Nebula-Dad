# Provider Setup Guide

## No Setup Required

These 5 providers work immediately with no account needed:

| Provider | Notes |
|----------|-------|
| Pollinations AI | Default provider, always ready |
| Puter • GPT-4o | Via Puter SDK, loaded automatically |
| Puter • Claude Sonnet 4 | Via Puter SDK, loaded automatically |
| OpenRouter • Llama 3.1 | Rate-limited free tier |
| OpenRouter • Gemma 2 | Rate-limited free tier |

## Getting Free API Keys

### Google Gemini (Recommended — most generous free tier)
1. Go to [aistudio.google.com/apikey](https://aistudio.google.com/apikey)
2. Sign in with a Google account
3. Click **Create API key**
4. Free tier: 15 RPM, 1M tokens/day

### Groq (Fastest responses)
1. Go to [console.groq.com](https://console.groq.com)
2. Sign up (free)
3. Keys → Create API key

### Mistral AI
1. Go to [console.mistral.ai](https://console.mistral.ai)
2. Sign up → API Keys → Create

### Cohere
1. Go to [dashboard.cohere.com](https://dashboard.cohere.com)
2. Sign up → API Keys

### Together AI
1. Go to [api.together.xyz](https://api.together.xyz)
2. Sign up → get $5 free credit

### DeepSeek
1. Go to [platform.deepseek.com](https://platform.deepseek.com)
2. Sign up → API Keys

### Cerebras
1. Go to [cloud.cerebras.ai](https://cloud.cerebras.ai)
2. Sign up → API Keys

### GitHub Models (requires GitHub account)
1. Go to [github.com/settings/tokens](https://github.com/settings/tokens)
2. Generate new token (classic) → no special scopes needed
3. Models are free for GitHub users

### SambaNova
1. Go to [cloud.sambanova.ai](https://cloud.sambanova.ai)
2. Sign up → API Keys

### HuggingFace
1. Go to [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens)
2. Create new token → Read access

### AI21
1. Go to [studio.ai21.com](https://studio.ai21.com)
2. Sign up → API Keys

## Using 9Router

9Router is a local gateway that routes across 40+ providers with smart fallback.

```bash
npm install -g 9router
9router
# Dashboard at http://localhost:20128
```

In the app: 🔄 9Router tab → enter endpoint → Connect & Test.
