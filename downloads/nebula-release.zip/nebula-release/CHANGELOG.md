# Changelog

All notable changes to Nebula AI Pro will be documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [2.3.0] — 2026-05-24

### Added
- 8 visual themes: Forest Realm (default), Fire Realm, Water Realm, Shadow Realm, Cosmic, Neon City, Sakura, Volcanic, Minimal
- Canvas particle system: fireflies, embers, bubbles, wisps, stars, petals, grid pulses
- Web Audio synthesized sound effects (click, chime, send, receive) — no audio files
- Themed ambient music — 8 original compositions, one per theme mood
- Master mute button and volume slider in header/themes panel
- 3D card tilt on hover/touch (CSS perspective transform)
- Advanced visual controls: particles toggle, density slider, bg-animation toggle, performance mode, motion-off
- Themed knotwork SVG background patterns (themed colors per realm)
- Orbitron font loaded for Neon theme

### Fixed
- `particles.resize()` double-scale accumulation on orientation change
- `audio.startMusic()` race condition allowing duplicate music loops
- Clipboard copy corrupting text when AI response contained `📋` emoji
- Water/Shadow/Fire realms showing gold OOT knotwork (wrong color)
- Canvas/bg-pattern z-index paint order now deterministic across browsers
- `particles.draw()` no longer queries DOM dimensions every frame

---

## [2.2.0] — 2026-05-23

### Added
- Real `fetch()` API calls — replaces all fake "demo response" code
- SSE streaming parser for 14 of 17 providers
- AbortController Stop button — cancels in-flight requests
- Auto-fallback: tries next ready provider on failure
- 15 functional AI tools (Translate, Email, SQL, Regex, Unit Tests, etc.)
- Settings tab: memory toggle, streaming toggle, fallback toggle, system prompt
- Copy button on every message (uses childNodes, XSS-safe)
- Export chat as JSON
- Clear chat history and clear API keys buttons
- Puter.js SDK integration (GPT-4o, Claude Sonnet 4, DALL-E — no key)
- Real 9Router connection test

### Fixed (30+ bugs from original code)
- Chat showed hardcoded string instead of calling any AI
- "Test All" was `setTimeout(500)` with fake success
- 9Router always returned "Connected" without testing
- Provider cards had no click handler
- `innerHTML += user_input` XSS vulnerability
- Cloudflare URL had `YOUR_ACCOUNT` placeholder
- Pollinations endpoint path wrong
- Tools tab was decorative only
- Stats counters stuck at 0
- Groq/Mistral/Cohere/HuggingFace using outdated/deprecated models
- GitHub Models on old Azure endpoint
- Puter iframe blocked by X-Frame-Options (replaced with SDK)
- iOS auto-zoom on input focus (font-size: 16px fix)

---

## [2.1.0] — 2026-05-22

### Added
- 20+ free AI providers listed
- Dedicated 9Router tab
- Stats dashboard (requests, working, failed)
- Provider "Test All & Find Fastest" button

### Fixed
- Bottom content cutoff (`100dvh` dynamic viewport height)
- Safe area insets for notched phones
- Tab overflow on small screens

---

## [2.0.0] — 2026-05-21

### Added
- Puter.com-inspired desktop interface
- App grid launcher with icons
- Floating window system
- Bottom dock navigation
- Glassmorphism UI with animated background
- 9Router and Puter integration
- PWA installable (service worker + manifest)

---

## [1.0.0] — 2026-05-20

### Added
- Initial release
- Basic chat interface
- OpenRouter free tier integration
- Service worker for offline support
