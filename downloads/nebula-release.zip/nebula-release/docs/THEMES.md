# Theme Customization Guide

## Built-in Themes

| Theme | Particles | Music | Palette |
|-------|-----------|-------|---------|
| Forest Realm | Fireflies | Pastoral | Deep green + gold |
| Fire Realm | Rising embers | Tense | Dark red + orange |
| Water Realm | Bubbles | Calm | Deep blue + cyan |
| Shadow Realm | Purple wisps | Mysterious | Black + violet |
| Cosmic | Stars | Ambient | Dark purple + pink/teal |
| Neon City | Grid pulses | Electronic | Black + cyan/magenta |
| Sakura | Falling petals | Serene | Dark pink + blush |
| Volcanic | Dense embers | Tense | Near-black + red/gold |
| Minimal | None | Silent | Dark navy + indigo |

## Adding a New Theme (~30 lines total)

### 1. CSS block (paste before the closing `</style>` tag)

```css
[data-theme="my-theme"] {
  --bg: #050510;
  --bg-2: #0a0a20;
  --bg-card: #151530;
  --bg-card-2: #0f0f28;
  --accent: #ffd700;
  --accent-2: #ffec6e;
  --accent-glow: rgba(255,215,0,0.4);
  --text: #fff8dc;
  --text-dim: #c8b560;
  --border: rgba(255,215,0,0.25);
  --border-strong: rgba(255,215,0,0.5);
  --particle-color-1: #ffd700;
  --particle-color-2: #ffffff;
  --particle-color-3: #ffec6e;
}
```

### 2. JS entry (in the THEMES object)

```javascript
'my-theme': {
  name: 'My Theme',
  desc: 'A brief description',
  gradient: 'linear-gradient(135deg, #050510, #ffd700, #ffffff)',
  particles: { type: 'stars', count: 60 },
  musicMode: 'ambient'
}
```

### Available particle types
`fireflies` · `embers` · `bubbles` · `wisps` · `stars` · `petals` · `grid-pulses`

### Available music modes
`pastoral` · `calm` · `tense` · `mysterious` · `serene` · `ambient` · `electronic` · `silent`

The theme tile appears in the picker automatically.
