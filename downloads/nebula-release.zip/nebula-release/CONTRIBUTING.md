# Contributing to Nebula AI Pro

Thanks for your interest in contributing! Here's everything you need to know.

## Ways to Contribute

- **Report bugs** via [GitHub Issues](../../issues/new?template=bug_report.md)
- **Request features** via [GitHub Issues](../../issues/new?template=feature_request.md)
- **Submit pull requests** for bug fixes, new providers, tools, or themes
- **Improve documentation**
- **Share** the project with others who'd find it useful

## Pull Request Process

```bash
# 1. Fork the repo, then clone your fork
git clone https://github.com/YOUR_USERNAME/Nebula-V3.git
cd Nebula-V3

# 2. Create a branch
git checkout -b feature/your-feature-name

# 3. Make changes, test locally
python3 -m http.server 8000

# 4. Commit using conventional commits
git commit -m "feat: add DeepInfra provider"
git commit -m "fix: particles flicker on iOS"
git commit -m "docs: update provider table"

# 5. Push and open a PR
git push origin feature/your-feature-name
```

## Adding a New AI Provider

Open `index.html` and find the `PROVIDERS` object. Add your entry:

```javascript
'your-provider': {
  name: 'Your Provider Name',
  type: 'openai',           // openai | gemini | cohere | puter
  endpoint: 'https://api.your-provider.com/v1/chat/completions',
  model: 'model-name',
  noKey: false,             // true = works with no API key
  keyUrl: 'https://your-provider.com/api-keys',
  stream: true              // false if SSE not supported
}
```

That's it. The `callProvider()` function handles the rest automatically for OpenAI-compatible APIs.

## Adding a New Tool

Find the `TOOLS` object and add:

```javascript
mytool: {
  icon: '🎯',
  name: 'My Tool',
  prompt: (input, opts) => `Do something with: ${input}`,
  // optional options dropdown:
  options: { style: ['option1', 'option2'] }
}
```

## Adding a New Theme

**Step 1** — Add CSS variables block:
```css
[data-theme="my-theme"] {
  --bg: #000000;
  --bg-2: #111111;
  --bg-card: #222222;
  --bg-card-2: #1a1a1a;
  --accent: #ff0000;
  --accent-2: #ff4444;
  --accent-glow: rgba(255,0,0,0.4);
  --text: #ffffff;
  --text-dim: #aaaaaa;
  --border: rgba(255,0,0,0.25);
  --border-strong: rgba(255,0,0,0.5);
  --particle-color-1: #ff0000;
  --particle-color-2: #ffffff;
  --particle-color-3: #ff8888;
}
```

**Step 2** — Add to the `THEMES` object in JS:
```javascript
'my-theme': {
  name: 'My Theme',
  desc: 'Brief description',
  gradient: 'linear-gradient(135deg, #000, #f00, #fff)',
  particles: { type: 'embers', count: 40 }, // embers|fireflies|bubbles|wisps|stars|petals|grid-pulses
  musicMode: 'tense'  // pastoral|calm|tense|mysterious|serene|ambient|electronic|silent
}
```

That's all 30 lines. The theme appears in the picker automatically.

## Code Style

- Vanilla JS only — no frameworks, no build tools
- `textContent` for all user/AI content (never `innerHTML` with variable data)
- Async/await with try/catch on all API calls
- CSS custom properties for anything theme-related
- Comments on architectural decisions (the *why*, not the *what*)

## Testing Checklist Before PR

- [ ] App loads locally (`python3 -m http.server 8000`)
- [ ] No console errors on load
- [ ] Chat sends and receives a real response
- [ ] New feature works on mobile viewport (Chrome DevTools → iPhone)
- [ ] Themes still switch correctly
- [ ] Settings persist after page reload

## Commit Message Format

```
feat:     new feature
fix:      bug fix
docs:     documentation only
style:    formatting, no logic change
refactor: code change without feature/fix
perf:     performance improvement
chore:    build/config/maintenance
```

## Questions?

Open a [Discussion](../../discussions) — happy to help.
